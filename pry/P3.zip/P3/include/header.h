/*****************************************************************************/
/**   Ejemplo de un posible fichero de cabeceras donde situar las           **/
/** definiciones de constantes, variables y estructuras para MenosC.        **/
/** Los alumnos deberán adaptarlo al desarrollo de su propio compilador.     **/
/*****************************************************************************/

/********************************/
#define TRAZA printf("Linea %d",__LINE__)
/********************************/
#ifndef _HEADER_H
#define _HEADER_H

/************************************* Constantes simbólicas P2 */
#define TRUE 1
#define FALSE 0
#define GLOBAL 0
#define LOCAL 1
#define TALLA_TIPO_SIMPLE 1 /* Talla asociada a los tipos simples */
#define TALLA_SEGENLACES 2 /* Talla del segmento de Enlaces de Control */
#define NOT 29
/************************************* Variables Globales P2 */
extern int verTdS; /* Flag para saber si mostrar la TdS */
extern int dvar; /* Desplazamiento en el Segmento de Variables */
extern int niv; /* Nivel de anidamiento "global" o "local" */
/************************************* Variables externas definidas en el AL */
extern int yylex();
extern int yyparse();

extern FILE *yyin;                           /* Fichero de entrada           */
extern int   yylineno;                       /* Contador del numero de linea */
extern char *yytext;                         /* Patron detectado             */
/********* Funciones y variables externas definidas en el Programa Principal */
extern void yyerror(const char * msg) ;   /* Tratamiento de errores          */

extern int verbosidad;                   /* Flag si se desea una traza       */
extern int numErrores;              /* Contador del numero de errores        */


/************************************************ Struct para los registros */
typedef struct arg {
    int ref;
    int talla;
} ARGU;

/************************************************ Struct para las expresiones */
typedef struct expre {
    int pos;
    int tipo;
} EXPR;

typedef struct for_inst /****** Estructura para los for */
{
  int ini;            
  int lv;        
  int lf; 
  int aux;        
}FOR_INST;

#endif  /* _HEADER_H */
/*****************************************************************************/
